model:CreateSequence(
	{
		name = "@WK_turns_lookFrame_0",
		snap = true,
		hidden = true,
		cmds = {
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 0, dst = 0 },
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 1, dst = 1 },
			{ cmd = "subtract", dst = 0, src = 1 }
		}
	}
)

model:CreateSequence(
	{
		name = "@WK_turns_lookFrame_1",
		snap = true,
		hidden = true,
		cmds = {
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 1, dst = 0 },
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 1, dst = 1 },
			{ cmd = "subtract", dst = 0, src = 1 }
		}
	}
)

model:CreateSequence(
	{
		name = "@WK_turns_lookFrame_2",
		snap = true,
		hidden = true,
		cmds = {
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 2, dst = 0 },
			{ cmd = "fetchframe", sequence = "@WK_turns", frame = 1, dst = 1 },
			{ cmd = "subtract", dst = 0, src = 1 }
		}
	}
)
